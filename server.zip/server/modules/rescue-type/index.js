module.exports = require("./routes");

const express = require("express");
const rescueType = require("../modules/rescue-type");

const router = express.Router();

router.use("/rescue-type", rescueType);


module.exports = router;
